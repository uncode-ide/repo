#!/usr/bin/env python3
"""gen_index.py — Generates HTML index page for the APT repo (gh-pages)."""

import os
import subprocess
import datetime
import glob

REPO_ROOT = "repo"
OUTPUT_FILE = os.path.join(REPO_ROOT, "index.html")
REPO_URL = "https://uncode-ide.github.io/repo"

def get_packages():
    packages = []
    for deb in glob.glob("debs/*.deb"):
        try:
            result = subprocess.run(
                ["dpkg-deb", "--field", deb,
                 "Package", "Version", "Architecture", "Description"],
                capture_output=True, text=True, check=True
            )
            fields = {}
            for line in result.stdout.strip().splitlines():
                if ": " in line:
                    k, v = line.split(": ", 1)
                    fields[k.strip()] = v.strip()
            fields["_size"] = f"{os.path.getsize(deb) / 1024:.1f} KB"
            packages.append(fields)
        except Exception as e:
            print(f"Warning: could not read {deb}: {e}")
    return sorted(packages, key=lambda p: p.get("Package", ""))

def main():
    packages = get_packages()
    now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    pkg_rows = ""
    for p in packages:
        name = p.get("Package", "?")
        version = p.get("Version", "?")
        arch = p.get("Architecture", "?")
        desc = p.get("Description", "").split("\n")[0]
        size = p.get("_size", "?")
        pkg_rows += f"""
            <tr>
              <td><span class="pkg-name">{name}</span></td>
              <td>{version}</td>
              <td>{arch}</td>
              <td class="desc">{desc}</td>
              <td class="size">{size}</td>
            </tr>"""

    pkg_count = len(packages)
    pkg_table = f"""
        <table>
          <thead>
            <tr>
              <th>Package</th>
              <th>Version</th>
              <th>Arch</th>
              <th>Description</th>
              <th>Size</th>
            </tr>
          </thead>
          <tbody>{pkg_rows}
          </tbody>
        </table>""" if packages else """
        <p class="empty">No packages available yet.</p>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Uncode IDE — APT Repository</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

    :root {{
      --bg:       #0f0f0f;
      --surface:  #1a1a1a;
      --border:   #2a2a2a;
      --text:     #e0e0e0;
      --muted:    #666;
      --green:    #4ade80;
      --blue:     #60a5fa;
      --mono:     'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Consolas', monospace;
      --sans:     -apple-system, 'Segoe UI', sans-serif;
    }}

    body {{
      background: var(--bg);
      color: var(--text);
      font-family: var(--sans);
      font-size: 14px;
      line-height: 1.6;
      min-height: 100vh;
    }}

    /* ── Header ── */
    header {{
      border-bottom: 1px solid var(--border);
      padding: 20px 40px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }}
    .header-left {{ display: flex; align-items: center; gap: 12px; }}
    .header-left h1 {{
      font-size: 15px;
      font-weight: 600;
      color: var(--text);
      letter-spacing: 0.01em;
    }}
    .header-left span {{
      font-size: 13px;
      color: var(--muted);
      font-weight: 400;
    }}
    .dot {{
      width: 8px; height: 8px;
      background: var(--green);
      border-radius: 50%;
      flex-shrink: 0;
    }}
    .built-at {{
      font-size: 12px;
      color: var(--muted);
      font-family: var(--mono);
    }}

    /* ── Main layout ── */
    main {{
      max-width: 860px;
      margin: 0 auto;
      padding: 48px 40px;
    }}

    section {{ margin-bottom: 48px; }}

    h2 {{
      font-size: 12px;
      font-weight: 600;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.1em;
      margin-bottom: 16px;
    }}

    /* ── Code blocks ── */
    .code-block {{
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 14px 18px;
      font-family: var(--mono);
      font-size: 13px;
      color: var(--green);
      overflow-x: auto;
      margin-bottom: 8px;
      white-space: pre;
    }}
    .code-block .dim {{ color: var(--muted); }}

    /* ── Steps ── */
    .steps {{ display: flex; flex-direction: column; gap: 20px; }}
    .step {{ display: flex; gap: 16px; align-items: flex-start; }}
    .step-num {{
      width: 22px; height: 22px;
      border: 1px solid var(--border);
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px;
      color: var(--muted);
      flex-shrink: 0;
      margin-top: 2px;
    }}
    .step-body {{ flex: 1; }}
    .step-label {{
      font-size: 13px;
      color: var(--text);
      margin-bottom: 8px;
    }}

    /* ── Key-value info ── */
    .info-grid {{
      display: grid;
      grid-template-columns: 140px 1fr;
      gap: 0;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 6px;
      overflow: hidden;
    }}
    .info-grid .k, .info-grid .v {{
      padding: 10px 16px;
      font-size: 13px;
      border-bottom: 1px solid var(--border);
    }}
    .info-grid .k:last-of-type,
    .info-grid .v:last-of-type {{ border-bottom: none; }}
    .info-grid .k {{ color: var(--muted); }}
    .info-grid .v {{ font-family: var(--mono); color: var(--text); }}

    /* ── Package table ── */
    table {{
      width: 100%;
      border-collapse: collapse;
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 6px;
      overflow: hidden;
    }}
    th {{
      text-align: left;
      padding: 10px 16px;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--muted);
      border-bottom: 1px solid var(--border);
      background: #111;
    }}
    td {{
      padding: 11px 16px;
      font-size: 13px;
      border-bottom: 1px solid var(--border);
      vertical-align: top;
    }}
    tr:last-child td {{ border-bottom: none; }}
    tr:hover td {{ background: rgba(255,255,255,0.02); }}
    .pkg-name {{
      font-family: var(--mono);
      color: var(--blue);
    }}
    td.desc {{ color: var(--muted); }}
    td.size {{ color: var(--muted); font-family: var(--mono); font-size: 12px; }}

    .pkg-count {{
      font-size: 12px;
      color: var(--muted);
      font-family: var(--mono);
      margin-bottom: 12px;
    }}
    .empty {{
      color: var(--muted);
      font-size: 13px;
      padding: 24px 0;
    }}

    /* ── Footer ── */
    footer {{
      border-top: 1px solid var(--border);
      padding: 20px 40px;
      font-size: 12px;
      color: var(--muted);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }}

    @media (max-width: 600px) {{
      header, footer {{ padding: 16px 20px; flex-direction: column; align-items: flex-start; gap: 8px; }}
      main {{ padding: 32px 20px; }}
      td.desc, th:nth-child(4), td:nth-child(4) {{ display: none; }}
    }}
  </style>
</head>
<body>

  <header>
    <div class="header-left">
      <div class="dot"></div>
      <h1>Uncode IDE APT Repository <span>/ com.uncode.ide</span></h1>
    </div>
    <span class="built-at">built {now}</span>
  </header>

  <main>

    <section>
      <h2>Quick Install</h2>
      <div class="code-block"><span class="dim">$</span> curl -fsSL {REPO_URL}/install.sh | bash</div>
    </section>

    <section>
      <h2>Manual Setup</h2>
      <div class="steps">
        <div class="step">
          <div class="step-num">1</div>
          <div class="step-body">
            <div class="step-label">Add the repository source</div>
            <div class="code-block"><span class="dim">$</span> echo "deb [arch=aarch64] {REPO_URL} uncode main" \\
    &gt; $PREFIX/etc/apt/sources.list.d/uncode.list</div>
          </div>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <div class="step-body">
            <div class="step-label">Install the GPG signing key</div>
            <div class="code-block"><span class="dim">$</span> curl -fsSL {REPO_URL}/assets/uncode.gpg \\
    -o $PREFIX/etc/apt/trusted.gpg.d/uncode.gpg</div>
          </div>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <div class="step-body">
            <div class="step-label">Update and install packages</div>
            <div class="code-block"><span class="dim">$</span> pkg update
<span class="dim">$</span> pkg install &lt;package-name&gt;</div>
          </div>
        </div>
      </div>
    </section>

    <section>
      <h2>Packages <span class="pkg-count">({pkg_count} available)</span></h2>
      {pkg_table}
    </section>

    <section>
      <h2>Repository Info</h2>
      <div class="info-grid">
        <div class="k">URL</div>          <div class="v">{REPO_URL}</div>
        <div class="k">Distribution</div> <div class="v">uncode</div>
        <div class="k">Component</div>    <div class="v">main</div>
        <div class="k">Architecture</div> <div class="v">aarch64</div>
        <div class="k">Target</div>       <div class="v">com.uncode.ide</div>
        <div class="k">GPG Key</div>      <div class="v">{REPO_URL}/assets/uncode.gpg</div>
        <div class="k">Last built</div>   <div class="v">{now}</div>
      </div>
    </section>

  </main>

  <footer>
    <span>Uncode IDE APT Repository</span>
    <span>Built by GitHub Actions on push to main</span>
  </footer>

</body>
</html>"""

    os.makedirs(REPO_ROOT, exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        f.write(html)
    print(f"✓ Generated {OUTPUT_FILE}")

if __name__ == "__main__":
    main()
