#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "mzn" for configuration "Release"
set_property(TARGET mzn APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mzn PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libmzn.a"
  )

list(APPEND _cmake_import_check_targets mzn )
list(APPEND _cmake_import_check_files_for_mzn "/data/data/com.uncode.ide/files/usr/lib/libmzn.a" )

# Import target "minizinc" for configuration "Release"
set_property(TARGET minizinc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(minizinc PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/minizinc"
  )

list(APPEND _cmake_import_check_targets minizinc )
list(APPEND _cmake_import_check_files_for_minizinc "${_IMPORT_PREFIX}/bin/minizinc" )

# Import target "mzn2doc" for configuration "Release"
set_property(TARGET mzn2doc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(mzn2doc PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/mzn2doc"
  )

list(APPEND _cmake_import_check_targets mzn2doc )
list(APPEND _cmake_import_check_files_for_mzn2doc "${_IMPORT_PREFIX}/bin/mzn2doc" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
