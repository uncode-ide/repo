/data/data/com.uncode.ide/files/usr/bin/direnv hook fish | source
