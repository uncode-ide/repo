#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MINIZIP::minizip-ng" for configuration "Release"
set_property(TARGET MINIZIP::minizip-ng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MINIZIP::minizip-ng PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libminizip-ng.so"
  IMPORTED_SONAME_RELEASE "libminizip-ng.so"
  )

list(APPEND _cmake_import_check_targets MINIZIP::minizip-ng )
list(APPEND _cmake_import_check_files_for_MINIZIP::minizip-ng "/data/data/com.uncode.ide/files/usr/lib/libminizip-ng.so" )

# Import target "MINIZIP::ppmd" for configuration "Release"
set_property(TARGET MINIZIP::ppmd APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(MINIZIP::ppmd PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libppmd.a"
  )

list(APPEND _cmake_import_check_targets MINIZIP::ppmd )
list(APPEND _cmake_import_check_files_for_MINIZIP::ppmd "/data/data/com.uncode.ide/files/usr/lib/libppmd.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
