#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "dynamicedt3d" for configuration "Release"
set_property(TARGET dynamicedt3d APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(dynamicedt3d PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libdynamicedt3d.so"
  IMPORTED_SONAME_RELEASE "libdynamicedt3d.so"
  )

list(APPEND _cmake_import_check_targets dynamicedt3d )
list(APPEND _cmake_import_check_files_for_dynamicedt3d "${_IMPORT_PREFIX}/lib/libdynamicedt3d.so" )

# Import target "dynamicedt3d-static" for configuration "Release"
set_property(TARGET dynamicedt3d-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(dynamicedt3d-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libdynamicedt3d.a"
  )

list(APPEND _cmake_import_check_targets dynamicedt3d-static )
list(APPEND _cmake_import_check_files_for_dynamicedt3d-static "${_IMPORT_PREFIX}/lib/libdynamicedt3d.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
