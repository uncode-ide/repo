#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "wolfssl::wolfssl" for configuration "Release"
set_property(TARGET wolfssl::wolfssl APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(wolfssl::wolfssl PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libwolfssl.so"
  IMPORTED_SONAME_RELEASE "libwolfssl.so"
  )

list(APPEND _cmake_import_check_targets wolfssl::wolfssl )
list(APPEND _cmake_import_check_files_for_wolfssl::wolfssl "/data/data/com.uncode.ide/files/usr/lib/libwolfssl.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
