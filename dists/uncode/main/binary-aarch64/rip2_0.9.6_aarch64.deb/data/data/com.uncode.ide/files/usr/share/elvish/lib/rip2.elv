
use builtin;
use str;

set edit:completion:arg-completer[rip] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'rip'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'rip'= {
            cand --graveyard 'Directory where deleted files rest'
            cand -u 'Restore the specified files or the last file if none are specified'
            cand --unbury 'Restore the specified files or the last file if none are specified'
            cand -d 'Permanently deletes the graveyard'
            cand --decompose 'Permanently deletes the graveyard'
            cand -s 'Prints files that were deleted in the current directory'
            cand --seance 'Prints files that were deleted in the current directory'
            cand -i 'Print some info about FILES before burying'
            cand --inspect 'Print some info about FILES before burying'
            cand -f 'Non-interactive mode'
            cand --force 'Non-interactive mode'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
            cand completions 'Generate shell completions file'
            cand graveyard 'Print the graveyard path'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rip;completions'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rip;graveyard'= {
            cand -s 'Get the graveyard subdirectory of the current directory'
            cand --seance 'Get the graveyard subdirectory of the current directory'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'rip;help'= {
            cand completions 'Generate shell completions file'
            cand graveyard 'Print the graveyard path'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'rip;help;completions'= {
        }
        &'rip;help;graveyard'= {
        }
        &'rip;help;help'= {
        }
    ]
    $completions[$command]
}
