#!/data/data/com.uncode.ide/files/usr/bin/env python
# -*- coding: utf-8 -*-

def main():
    print("hello")
    print("there")

if __name__ == "__main__":
    main()
