#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "libtommath" for configuration "Release"
set_property(TARGET libtommath APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(libtommath PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libtommath.a"
  )

list(APPEND _cmake_import_check_targets libtommath )
list(APPEND _cmake_import_check_files_for_libtommath "/data/data/com.uncode.ide/files/usr/lib/libtommath.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
