#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "PortMidi::portmidi" for configuration "Release"
set_property(TARGET PortMidi::portmidi APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(PortMidi::portmidi PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libportmidi.so"
  IMPORTED_SONAME_RELEASE "libportmidi.so"
  )

list(APPEND _cmake_import_check_targets PortMidi::portmidi )
list(APPEND _cmake_import_check_files_for_PortMidi::portmidi "/data/data/com.uncode.ide/files/usr/lib/libportmidi.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
