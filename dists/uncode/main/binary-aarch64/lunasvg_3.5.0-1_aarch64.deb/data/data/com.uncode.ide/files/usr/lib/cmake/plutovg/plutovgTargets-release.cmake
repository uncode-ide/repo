#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "plutovg::plutovg" for configuration "Release"
set_property(TARGET plutovg::plutovg APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(plutovg::plutovg PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libplutovg.so"
  IMPORTED_SONAME_RELEASE "libplutovg.so"
  )

list(APPEND _cmake_import_check_targets plutovg::plutovg )
list(APPEND _cmake_import_check_files_for_plutovg::plutovg "/data/data/com.uncode.ide/files/usr/lib/libplutovg.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
