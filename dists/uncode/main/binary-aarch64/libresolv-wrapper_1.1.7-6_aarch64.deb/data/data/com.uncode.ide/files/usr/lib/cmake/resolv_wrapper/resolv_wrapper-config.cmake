set(RESOLV_WRAPPER_LIBRARY /data/data/com.uncode.ide/files/usr/lib/libresolv_wrapper.so)
