include(CMakeFindDependencyMacro)

# Same syntax as find_package
find_dependency(BLAS REQUIRED)
find_dependency(LAPACK REQUIRED)

# Add the targets file
include("${CMAKE_CURRENT_LIST_DIR}/qrupdateTargets.cmake")

