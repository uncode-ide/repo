eval (E:JUST_COMPLETE=elvish just | slurp)
