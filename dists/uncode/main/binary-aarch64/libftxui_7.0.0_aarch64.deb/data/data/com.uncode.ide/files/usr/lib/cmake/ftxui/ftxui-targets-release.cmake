#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ftxui::screen" for configuration "Release"
set_property(TARGET ftxui::screen APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ftxui::screen PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libftxui-screen.so"
  IMPORTED_SONAME_RELEASE "libftxui-screen.so"
  )

list(APPEND _cmake_import_check_targets ftxui::screen )
list(APPEND _cmake_import_check_files_for_ftxui::screen "/data/data/com.uncode.ide/files/usr/lib/libftxui-screen.so" )

# Import target "ftxui::dom" for configuration "Release"
set_property(TARGET ftxui::dom APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ftxui::dom PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libftxui-dom.so"
  IMPORTED_SONAME_RELEASE "libftxui-dom.so"
  )

list(APPEND _cmake_import_check_targets ftxui::dom )
list(APPEND _cmake_import_check_files_for_ftxui::dom "/data/data/com.uncode.ide/files/usr/lib/libftxui-dom.so" )

# Import target "ftxui::component" for configuration "Release"
set_property(TARGET ftxui::component APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ftxui::component PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libftxui-component.so"
  IMPORTED_SONAME_RELEASE "libftxui-component.so"
  )

list(APPEND _cmake_import_check_targets ftxui::component )
list(APPEND _cmake_import_check_files_for_ftxui::component "/data/data/com.uncode.ide/files/usr/lib/libftxui-component.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
