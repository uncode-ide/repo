#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "spatialindex" for configuration "Release"
set_property(TARGET spatialindex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spatialindex PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libspatialindex.so"
  IMPORTED_SONAME_RELEASE "libspatialindex.so"
  )

list(APPEND _cmake_import_check_targets spatialindex )
list(APPEND _cmake_import_check_files_for_spatialindex "/data/data/com.uncode.ide/files/usr/lib/libspatialindex.so" )

# Import target "spatialindex_c" for configuration "Release"
set_property(TARGET spatialindex_c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(spatialindex_c PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libspatialindex_c.so"
  IMPORTED_SONAME_RELEASE "libspatialindex_c.so"
  )

list(APPEND _cmake_import_check_targets spatialindex_c )
list(APPEND _cmake_import_check_files_for_spatialindex_c "/data/data/com.uncode.ide/files/usr/lib/libspatialindex_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
