# https://sw.kovidgoyal.net/kitty/index.html
# ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾

provide-module kitty %{

# ensure that we're running on kitty
evaluate-commands %sh{
    [ -z "${kak_opt_windowing_modules}" ] || [ "$TERM" = "xterm-kitty" ] || echo 'fail Kitty not detected'
}

declare-option -docstring %{window type that kitty creates on new and repl calls (window|os-window)} str kitty_window_type window

define-command kitty-terminal-window -params 1.. -docstring '
kitty-terminal-window <program> [<arguments>]: create a new terminal as a kitty window
The program passed as argument will be executed in the new terminal' \
%{
    evaluate-commands %sh{
        match=""
        if [ -n "$kak_client_env_KITTY_WINDOW_ID" ]; then
            match="--match=window_id:$kak_client_env_KITTY_WINDOW_ID"
        fi

        listen=""
        if [ -n "$kak_client_env_KITTY_LISTEN_ON" ]; then
            listen="--to=$kak_client_env_KITTY_LISTEN_ON"
        fi

        kitty @ $listen launch --type="$kak_opt_kitty_window_type" --cwd="$PWD" $match "$@" >/dev/null ||
            echo 'fail %{kitty-terminal-window: failure running `kitty @`, see `:buffer *debug*`}'
    }
}
complete-command kitty-terminal-window shell

define-command kitty-terminal-tab -params 1.. -docstring '
kitty-terminal-tab <program> [<arguments>]: create a new terminal as kitty tab
The program passed as argument will be executed in the new terminal' \
%{
    evaluate-commands %sh{
        match=""
        if [ -n "$kak_client_env_KITTY_WINDOW_ID" ]; then
            match="--match=window_id:$kak_client_env_KITTY_WINDOW_ID"
        fi

        listen=""
        if [ -n "$kak_client_env_KITTY_LISTEN_ON" ]; then
            listen="--to=$kak_client_env_KITTY_LISTEN_ON"
        fi

        kitty @ $listen launch --type=tab --cwd="$PWD" $match "$@" >/dev/null ||
            echo 'fail %{kitty-terminal-tab: failure running `kitty @`, see `:buffer *debug*`}'
    }
}
complete-command kitty-terminal-tab shell

define-command kitty-focus -params ..1 -docstring '
kitty-focus [<client>]: focus the given client
If no client is passed then the current one is used' \
%{
    evaluate-commands %sh{
        if [ $# -eq 1 ]; then
            printf "evaluate-commands -client '%s' focus" "$1"
        else
            match=""
            if [ -n "$kak_client_env_KITTY_WINDOW_ID" ]; then
                match="--match=id:$kak_client_env_KITTY_WINDOW_ID"
            fi

            listen=""
            if [ -n "$kak_client_env_KITTY_LISTEN_ON" ]; then
                listen="--to=$kak_client_env_KITTY_LISTEN_ON"
            fi

            kitty @ $listen focus-window $match >/dev/null ||
                echo 'fail %{kitty-focus: failure running `kitty @`, see `:buffer *debug*`}'
        fi
    }
}
complete-command -menu kitty-focus client

alias global focus kitty-focus

# deprecated
define-command -hidden kitty-terminal -params 1.. %{
    kitty-terminal-window %arg{@}
}

}
