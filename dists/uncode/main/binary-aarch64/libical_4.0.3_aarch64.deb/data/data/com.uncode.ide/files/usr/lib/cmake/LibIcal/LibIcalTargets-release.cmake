#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ical" for configuration "Release"
set_property(TARGET ical APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libical.so"
  IMPORTED_SONAME_RELEASE "libical.so"
  )

list(APPEND _cmake_import_check_targets ical )
list(APPEND _cmake_import_check_files_for_ical "/data/data/com.uncode.ide/files/usr/lib/libical.so" )

# Import target "ical_cxx" for configuration "Release"
set_property(TARGET ical_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical_cxx PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libical_cxx.so"
  IMPORTED_SONAME_RELEASE "libical_cxx.so"
  )

list(APPEND _cmake_import_check_targets ical_cxx )
list(APPEND _cmake_import_check_files_for_ical_cxx "/data/data/com.uncode.ide/files/usr/lib/libical_cxx.so" )

# Import target "icalss" for configuration "Release"
set_property(TARGET icalss APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalss PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libicalss.so"
  IMPORTED_SONAME_RELEASE "libicalss.so"
  )

list(APPEND _cmake_import_check_targets icalss )
list(APPEND _cmake_import_check_files_for_icalss "/data/data/com.uncode.ide/files/usr/lib/libicalss.so" )

# Import target "icalss_cxx" for configuration "Release"
set_property(TARGET icalss_cxx APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalss_cxx PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libicalss_cxx.so"
  IMPORTED_SONAME_RELEASE "libicalss_cxx.so"
  )

list(APPEND _cmake_import_check_targets icalss_cxx )
list(APPEND _cmake_import_check_files_for_icalss_cxx "/data/data/com.uncode.ide/files/usr/lib/libicalss_cxx.so" )

# Import target "icalvcal" for configuration "Release"
set_property(TARGET icalvcal APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalvcal PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libicalvcal.so"
  IMPORTED_SONAME_RELEASE "libicalvcal.so"
  )

list(APPEND _cmake_import_check_targets icalvcal )
list(APPEND _cmake_import_check_files_for_icalvcal "/data/data/com.uncode.ide/files/usr/lib/libicalvcal.so" )

# Import target "icalvcard" for configuration "Release"
set_property(TARGET icalvcard APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(icalvcard PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libicalvcard.so"
  IMPORTED_SONAME_RELEASE "libicalvcard.so"
  )

list(APPEND _cmake_import_check_targets icalvcard )
list(APPEND _cmake_import_check_files_for_icalvcard "/data/data/com.uncode.ide/files/usr/lib/libicalvcard.so" )

# Import target "ical_jni" for configuration "Release"
set_property(TARGET ical_jni APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ical_jni PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libical_jni.so"
  IMPORTED_SONAME_RELEASE "libical_jni.so"
  )

list(APPEND _cmake_import_check_targets ical_jni )
list(APPEND _cmake_import_check_files_for_ical_jni "/data/data/com.uncode.ide/files/usr/lib/libical_jni.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
