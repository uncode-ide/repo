[
 (entity_definition)
] @fold
