; inherits: xml
