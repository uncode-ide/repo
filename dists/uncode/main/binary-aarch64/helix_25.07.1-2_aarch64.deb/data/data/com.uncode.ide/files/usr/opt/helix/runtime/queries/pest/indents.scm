[
  (expression)
] @indent

[
  "]"
  "}"
  ")"
] @outdent
