#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "Zopfli::libzopfli" for configuration "Release"
set_property(TARGET Zopfli::libzopfli APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Zopfli::libzopfli PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libzopfli.so"
  IMPORTED_SONAME_RELEASE "libzopfli.so"
  )

list(APPEND _cmake_import_check_targets Zopfli::libzopfli )
list(APPEND _cmake_import_check_files_for_Zopfli::libzopfli "/data/data/com.uncode.ide/files/usr/lib/libzopfli.so" )

# Import target "Zopfli::libzopflipng" for configuration "Release"
set_property(TARGET Zopfli::libzopflipng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Zopfli::libzopflipng PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.uncode.ide/files/usr/lib/libzopflipng.so"
  IMPORTED_SONAME_RELEASE "libzopflipng.so"
  )

list(APPEND _cmake_import_check_targets Zopfli::libzopflipng )
list(APPEND _cmake_import_check_files_for_Zopfli::libzopflipng "/data/data/com.uncode.ide/files/usr/lib/libzopflipng.so" )

# Import target "Zopfli::zopfli" for configuration "Release"
set_property(TARGET Zopfli::zopfli APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Zopfli::zopfli PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/zopfli"
  )

list(APPEND _cmake_import_check_targets Zopfli::zopfli )
list(APPEND _cmake_import_check_files_for_Zopfli::zopfli "${_IMPORT_PREFIX}/bin/zopfli" )

# Import target "Zopfli::zopflipng" for configuration "Release"
set_property(TARGET Zopfli::zopflipng APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(Zopfli::zopflipng PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/bin/zopflipng"
  )

list(APPEND _cmake_import_check_targets Zopfli::zopflipng )
list(APPEND _cmake_import_check_files_for_Zopfli::zopflipng "${_IMPORT_PREFIX}/bin/zopflipng" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
