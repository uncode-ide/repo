// SPDX-FileCopyrightText: 2026 Kohei Yoshida
//
// SPDX-License-Identifier: MIT

#pragma once

#define MDDS_VERSION "3.2.1"
#define MDDS_VERSION_MAJOR 3
#define MDDS_VERSION_MINOR 2
#define MDDS_VERSION_MICRO 1

#define MDDS_API_VERSION "3.0"
#define MDDS_API_VERSION_MAJOR 3
#define MDDS_API_VERSION_MINOR 0
