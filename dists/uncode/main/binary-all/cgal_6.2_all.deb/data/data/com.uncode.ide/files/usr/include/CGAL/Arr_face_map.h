// Copyright (c) 2005,2007,2008,2009,2010,2011 Tel-Aviv University (Israel).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org).
//
// $URL: https://github.com/CGAL/cgal/blob/v6.2/Arrangement_on_surface_2/include/CGAL/Arr_face_map.h $
// $Id: include/CGAL/Arr_face_map.h cac3e9d75e2 $
// SPDX-License-Identifier: GPL-3.0-or-later OR LicenseRef-Commercial
//
//
// Author(s)     : Ron Wein          <wein@post.tau.ac.il>

#ifndef CGAL_ARR_FACE_MAP_H
#define CGAL_ARR_FACE_MAP_H

#include <CGAL/license/Arrangement_on_surface_2.h>

#define CGAL_DEPRECATED_HEADER "<CGAL/Arr_face_map.h>"
#define CGAL_REPLACEMENT_HEADER "<CGAL/Arr_face_index_map.h>"
#include <CGAL/Installation/internal/deprecation_warning.h>

#include <CGAL/Arr_face_index_map.h>

/*! \file
 * Definition of the Arr_face_index_map<Arrangement> class.

 */

#endif
