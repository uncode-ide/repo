/****************************************************************************
 * Core Library Version 1.7, August 2004
 * Copyright (c) 1995-2004 Exact Computation Project
 * All rights reserved.
 *
 * This file is part of CGAL (www.cgal.org).
 *
 * $URL: https://github.com/CGAL/cgal/blob/v6.2/CGAL_Core/include/CGAL/CORE/Config.h $
 * $Id: include/CGAL/CORE/Config.h cac3e9d75e2 $
 * SPDX-License-Identifier: LGPL-3.0-or-later
 ***************************************************************************/

#ifndef _CORE_CONFIG_H_
#define _CORE_CONFIG_H_

// disable debug
//#define CORE_DISABLE_DEBUG

// disable inline functions
//#define CORE_DISABLE_INLINE

// disable memory pool
//#define CORE_DISABLE_MEMPOOL

// debug reference counting
//#define CORE_RC_DEBUG 1

#include <CGAL/auto_link/CORE.h>

#include <CGAL/export/CORE.h>

#ifdef CGAL_CORE_DEBUG
#define CGAL_CORE_warning_msg(X ,Y) CGAL_warning_msg(X ,Y)
#else
#define CGAL_CORE_warning_msg(X ,Y)
#endif


#endif // _CORE_CONFIG_H_
