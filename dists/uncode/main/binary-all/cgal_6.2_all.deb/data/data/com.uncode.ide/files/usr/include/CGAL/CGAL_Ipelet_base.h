// Copyright (c) 2005-2009  INRIA Sophia-Antipolis (France).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org)
//
// $URL: https://github.com/CGAL/cgal/blob/v6.2/CGAL_ipelets/include/CGAL/CGAL_Ipelet_base.h $
// $Id: include/CGAL/CGAL_Ipelet_base.h cac3e9d75e2 $
// SPDX-License-Identifier: LGPL-3.0-or-later OR LicenseRef-Commercial
//
//
// Author(s)     : Sebastien Loriot, Sylvain Pion


#include <CGAL/config.h>

#include <CGAL/CGAL_Ipelet_base_v7.h>
